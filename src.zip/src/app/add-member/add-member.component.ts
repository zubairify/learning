import { Component } from '@angular/core';
import { Member } from 'src/member.model';
import { MemberService } from '../services/member.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-member',
  templateUrl: './add-member.component.html',
  styleUrls: ['./add-member.component.css']
})
export class AddMemberComponent {
  m : Member = new Member();

  constructor(private service : MemberService, private router : Router){}

  save() {
    this.service.save(this.m);
    this.router.navigate(['/login']);
  }

}
