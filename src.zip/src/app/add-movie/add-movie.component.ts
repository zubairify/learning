import { Component } from '@angular/core';
import { Movie } from 'src/movie.model';
import { MovieService } from '../services/movie.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent {
  m : Movie = new Movie();
  gens : string[] = ['Action', 'SciFi', 'Horror', 'Comedy'];
  langs : string[] = ['English', 'Hindi', 'Marathi', 'Tamil'];
  
  constructor(private service : MovieService, private router : Router){}
  
  save() {}
}
