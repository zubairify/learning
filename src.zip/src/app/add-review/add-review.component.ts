import { Component } from '@angular/core';
import { Review } from 'src/review.model';
import { ReviewService } from '../services/review.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.component.html',
  styleUrls: ['./add-review.component.css']
})
export class AddReviewComponent {
  r : Review = new Review();

  constructor(private service : ReviewService, private router : Router) {}

  save() {}
}
