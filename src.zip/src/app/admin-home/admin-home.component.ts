import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent {
  greet : string = '';

  constructor(private router : Router) {}

  ngOnInit() {
    if(localStorage.getItem("USER") == null)
      this.router.navigate(['/login']);
    else {
      this.greet = 'Hello, ' + localStorage.getItem('USER');
    }
  }
}
