import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AddMemberComponent } from './add-member/add-member.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { AddReviewComponent } from './add-review/add-review.component';
import { ListMemberComponent } from './list-member/list-member.component';
import { ListMovieComponent } from './list-movie/list-movie.component';
import { MovieByGenreComponent } from './movie-by-genre/movie-by-genre.component';
import { MovieByLanguageComponent } from './movie-by-language/movie-by-language.component';
import { MovieByReleaseComponent } from './movie-by-release/movie-by-release.component';
import { ReviewByMovieComponent } from './review-by-movie/review-by-movie.component';
import { ReviewByRatingComponent } from './review-by-rating/review-by-rating.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { MemberHomeComponent } from './member-home/member-home.component';

const routes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: 'add-member', component: AddMemberComponent},
  {path: 'add-movie', component: AddMovieComponent},
  {path: 'add-review', component: AddReviewComponent},
  {path: 'list-member', component: ListMemberComponent},
  {path: 'list-movie', component: ListMovieComponent},
  {path: 'movie-by-genre', component: MovieByGenreComponent},
  {path: 'movie-by-lang', component: MovieByLanguageComponent},
  {path: 'movie-by-release', component: MovieByReleaseComponent},
  {path: 'review-by-movie', component: ReviewByMovieComponent},
  {path: 'review-by-rating', component: ReviewByRatingComponent},
  {path: 'admin-home', component: AdminHomeComponent},
  {path: 'member-home', component: MemberHomeComponent},
  {path: 'logout', redirectTo: '/login', pathMatch: 'full'},
  {path: '', redirectTo: '/login', pathMatch: 'full'},
  {path: '**', redirectTo: '/login', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
