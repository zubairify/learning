import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'rating-app';
  flag = false;

  ngOnInit() {
    if(localStorage.getItem("USER") != null)
      this.flag = true;
  }
}
