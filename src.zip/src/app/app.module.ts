import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AddMemberComponent } from './add-member/add-member.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { AddReviewComponent } from './add-review/add-review.component';
import { LoginComponent } from './login/login.component';
import { ListMemberComponent } from './list-member/list-member.component';
import { ListMovieComponent } from './list-movie/list-movie.component';
import { MovieByGenreComponent } from './movie-by-genre/movie-by-genre.component';
import { MovieByLanguageComponent } from './movie-by-language/movie-by-language.component';
import { MovieByReleaseComponent } from './movie-by-release/movie-by-release.component';
import { ReviewByMovieComponent } from './review-by-movie/review-by-movie.component';
import { ReviewByRatingComponent } from './review-by-rating/review-by-rating.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { MemberHomeComponent } from './member-home/member-home.component';

@NgModule({
  declarations: [
    AppComponent,
    AddMemberComponent,
    AddMovieComponent,
    AddReviewComponent,
    LoginComponent,
    ListMemberComponent,
    ListMovieComponent,
    MovieByGenreComponent,
    MovieByLanguageComponent,
    MovieByReleaseComponent,
    ReviewByMovieComponent,
    ReviewByRatingComponent,
    AdminHomeComponent,
    MemberHomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
