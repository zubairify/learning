import { Component } from '@angular/core';
import { Member } from 'src/member.model';
import { MemberService } from '../services/member.service';

@Component({
  selector: 'app-list-member',
  templateUrl: './list-member.component.html',
  styleUrls: ['./list-member.component.css']
})
export class ListMemberComponent {
  members : Member[] = [];

  constructor(private service : MemberService) {}

  ngOnInit() {}
}
