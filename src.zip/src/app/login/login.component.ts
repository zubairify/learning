import { Component } from '@angular/core';
import { Login } from 'src/login.model';
import { MemberService } from '../services/member.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  auth : Login = new Login();

  constructor(private service : MemberService, private router : Router) {
    localStorage.clear();
  }

  validate() {
    if(this.auth.email == 'admin@cg.com' && this.auth.password == 'secret') {
      // admin login successfull - navigate to admin home
      localStorage.setItem("USER", "admin");
      this.router.navigate(['/admin-home']);
    } else if(this.service.login(this.auth)) {
      // user login successfull - navigate to user home
      localStorage.setItem("USER", "zubair");
      this.router.navigate(['/member-home']);
    } else 
      alert("Invalid Email ID/Password");
  }
}
