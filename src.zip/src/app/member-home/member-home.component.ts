import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-member-home',
  templateUrl: './member-home.component.html',
  styleUrls: ['./member-home.component.css']
})
export class MemberHomeComponent {
  greet : string = '';
  
  constructor(private router : Router) {}
  
  ngOnInit() {
    if(localStorage.getItem("USER") == null)
      this.router.navigate(['/login']);
    else {
      this.greet = 'Hello, ' + localStorage.getItem('USER');
    }
  }
}
