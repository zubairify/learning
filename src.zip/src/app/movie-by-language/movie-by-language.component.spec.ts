import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MovieByLanguageComponent } from './movie-by-language.component';

describe('MovieByLanguageComponent', () => {
  let component: MovieByLanguageComponent;
  let fixture: ComponentFixture<MovieByLanguageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MovieByLanguageComponent]
    });
    fixture = TestBed.createComponent(MovieByLanguageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
