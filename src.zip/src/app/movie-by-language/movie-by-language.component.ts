import { Component } from '@angular/core';

@Component({
  selector: 'app-movie-by-language',
  templateUrl: './movie-by-language.component.html',
  styleUrls: ['./movie-by-language.component.css']
})
export class MovieByLanguageComponent {

}
