import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MovieByReleaseComponent } from './movie-by-release.component';

describe('MovieByReleaseComponent', () => {
  let component: MovieByReleaseComponent;
  let fixture: ComponentFixture<MovieByReleaseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MovieByReleaseComponent]
    });
    fixture = TestBed.createComponent(MovieByReleaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
