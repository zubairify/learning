import { Component } from '@angular/core';

@Component({
  selector: 'app-movie-by-release',
  templateUrl: './movie-by-release.component.html',
  styleUrls: ['./movie-by-release.component.css']
})
export class MovieByReleaseComponent {

}
