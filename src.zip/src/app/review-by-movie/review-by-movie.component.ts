import { Component } from '@angular/core';

@Component({
  selector: 'app-review-by-movie',
  templateUrl: './review-by-movie.component.html',
  styleUrls: ['./review-by-movie.component.css']
})
export class ReviewByMovieComponent {

}
