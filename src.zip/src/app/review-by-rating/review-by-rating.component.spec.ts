import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewByRatingComponent } from './review-by-rating.component';

describe('ReviewByRatingComponent', () => {
  let component: ReviewByRatingComponent;
  let fixture: ComponentFixture<ReviewByRatingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReviewByRatingComponent]
    });
    fixture = TestBed.createComponent(ReviewByRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
