import { Component } from '@angular/core';

@Component({
  selector: 'app-review-by-rating',
  templateUrl: './review-by-rating.component.html',
  styleUrls: ['./review-by-rating.component.css']
})
export class ReviewByRatingComponent {

}
