import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Login } from 'src/login.model';
import { Member } from 'src/member.model';

@Injectable({
  providedIn: 'root'
})
export class MemberService {

  constructor(private http : HttpClient) { }

  save(m : Member) {}

  list() {}

  login(auth : Login) {
    if(true) {
      return true;
    } else {
      return false;
    }
  }
}
