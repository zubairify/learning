import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Movie } from 'src/movie.model';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  constructor(private http : HttpClient) { }

  save(m : Movie) {}

  list() {}

  byGenre(genre : string) {}  

  byLang(lang : string) {}

  byRelease(begin : Date, end : Date) {}
}
