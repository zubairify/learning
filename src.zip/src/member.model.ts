export class Member { 
    public mid : number = 0;
    public name : string = '';
    public age : number = 0;
    public email : string = '';
    public password : string = '';
}
