export class Movie { 
    public fid : number = 0;
    public title : string = '';
    public genre : string = '';
    public language : string = '';
    public release : Date = new Date();
}
