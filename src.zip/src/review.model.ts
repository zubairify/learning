export class Review {
    public rid : number = 0;
    public mid : number = 0;
    public fid : number = 0;
    public rating : number = 0;
    public comment : string = '';
}
